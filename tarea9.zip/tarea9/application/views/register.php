<?php

if($_POST){
    $CI =& get_instance();
    $f = new stdClass();
    $f->email = $_POST['email'];
    $f->password = md5($_POST['password']);
    
    $CI->db->insert('person', $f);
    $cod = $this->db->insert_id();
    
    $photo = $_FILES['photo'];
    
    if($photo['error'] == 0){
        $tmp = "photos/{$cod}.jpg";
        move_uploaded_file($photo['tmp_name'], $tmp);
    }
    
    redirect('login');
    
}
?>
  <html>

  <head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <title>
      Twitter Clone
    </title>
  </head>

  <body>
    <fieldset>
      <legend class="text-center">
        Registrarse
      </legend>
      <div class="container">
        <div class="row">
          <form enctype="multipart/form-data" method="post" action="">
            <div class="form-group input-group col-md-4">
              <label class="input-group-addon">Correo: </label>
              <input type="email" required name="email" class="form-control" />
            </div>
            <div class="form-group input-group col-md-4">
              <label class="input-group-addon">Contraseña: </label>
              <input type="password" required name="password" class="form-control" />
            </div>
            <div class="form-group input-group col-md-4">
              <label class="input-group-addon">Imágen: </label>
              <input type="file" required name="photo" class="form-control" />
            </div>
            <div>
              <button type="submit" class="btn btn-success">Registrarse </button>
            </div>
            <div>
            </div>
          </form>
        </div>
      </div>
    </fieldset>
  </body>

  </html>