<?php
// The following lines check if the user exists in the database.
$this->load->database();
$message = "";
if($_POST){
    $sql = "select * from person where email = ? and password = ?";
    $CI =& get_instance();
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $rs = $CI->db->query($sql, array($email, $password));
    $rs = $rs->result();
    // The user exists in the database
    if(count($rs) > 0){
        $_SESSION['itla_bike_user'] = $rs[0];
        //I redirect this to admin because if it is set it is better to show the start page
        // in this view you should be able to see all the info of the user
        redirect('wall');
        // The user does not exist in the database
    } else {
        $message = "Usuario o contraseña no válida";
    }
}
?>

  <html>

  <head>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <title>
      Twitter Clone
    </title>
  </head>

  <body>
    <fieldset>
      <legend class="text-center">
        Inicia sesión
      </legend>
      <div class="container">
        <div class="row">
          <form method="post" action="">
            <div class="form-group input-group col-md-4">
              <label class="input-group-addon">Correo: </label>
              <input type="email" required name="email" class="form-control" />
            </div>
            <div class="form-group input-group col-md-4">
              <label class="input-group-addon">Contraseña: </label>
              <input type="password" required name="password" class="form-control" />
            </div>
            <div style="color:red">
              <?php echo $message; ?>
            </div>
            <div class="col-md-2">
              <button class="btn btn-primary">Iniciar sesión</button>
            </div>
            <div class="col-md-2">
              <a href="<?php echo base_url('register') ?>" class="btn btn-info"> Registrarse</a>
            </div>
          </form>
        </div>
      </div>
    </fieldset>
  </body>

  </html>